01. [Azure App Service를 사용하여 웹 애플리케이션 호스트](https://learn.microsoft.com/ko-kr/training/modules/host-a-web-app-with-azure-app-service/)

00. [Azure Web App에 Streamlit 배포하기](02.streamlit_deployment.md)
