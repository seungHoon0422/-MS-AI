Day 4

[01. OpenAI Services](https://learn.microsoft.com/ko-kr/training/paths/develop-ai-solutions-azure-openai/)

[02. Streamlit의 이해와 활용](./streamlit/streamlit.md)

[03. Streamlit Chat Interface programming]()